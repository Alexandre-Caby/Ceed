Comparer un produit :
	Générer un tableau qui peut s’agrandir :	
	Lister les sites marchands les plus connus : topachat
