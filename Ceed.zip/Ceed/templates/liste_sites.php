<?php
$liste_des_sites =  listerSites();
mktable($liste_des_sites);

?>