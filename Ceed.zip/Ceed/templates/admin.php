Admin : 
Supprimer / blacklister / warninguer les users malfaisants (3 warnings = ban)
Ajouter des sites aux listes
