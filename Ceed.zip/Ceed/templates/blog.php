Blog (finir par cette partie si on a le temps) :
	Parler des sites, donner ses avis (Ajouter / supprimer ses messages 


	TO DO : Ne pas oublier les memes dans les commentaires 
