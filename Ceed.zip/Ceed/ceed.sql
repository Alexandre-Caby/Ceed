-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : lun. 24 mai 2021 à 14:56
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ceed`
--

-- --------------------------------------------------------

--
-- Structure de la table `association_produit`
--

DROP TABLE IF EXISTS `association_produit`;
CREATE TABLE IF NOT EXISTS `association_produit` (
  `idProduit` int(11) NOT NULL,
  `idSite` int(11) NOT NULL,
  PRIMARY KEY (`idProduit`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `association_site`
--

DROP TABLE IF EXISTS `association_site`;
CREATE TABLE IF NOT EXISTS `association_site` (
  `idSite` int(11) NOT NULL,
  `idType` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `association_site`
--

INSERT INTO `association_site` (`idSite`, `idType`) VALUES
(1, 1),
(4, 1),
(1, 2),
(1, 3),
(1, 4),
(5, 2),
(5, 4),
(2, 1),
(2, 4),
(8, 1),
(8, 4),
(8, 2);

-- --------------------------------------------------------

--
-- Structure de la table `avis`
--

DROP TABLE IF EXISTS `avis`;
CREATE TABLE IF NOT EXISTS `avis` (
  `idAvis` int(11) NOT NULL AUTO_INCREMENT,
  `idUser` int(11) NOT NULL,
  `note` float NOT NULL,
  `commentaire` varchar(500) NOT NULL,
  `idProduit` int(11) NOT NULL,
  PRIMARY KEY (`idAvis`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `avis`
--

INSERT INTO `avis` (`idAvis`, `idUser`, `note`, `commentaire`, `idProduit`) VALUES
(1, 2, 15, 'J\'adore cet écran !\r\n', 39);

-- --------------------------------------------------------

--
-- Structure de la table `gamme`
--

DROP TABLE IF EXISTS `gamme`;
CREATE TABLE IF NOT EXISTS `gamme` (
  `gamme` varchar(50) DEFAULT NULL,
  `idGamme` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `gamme`
--

INSERT INTO `gamme` (`gamme`, `idGamme`) VALUES
('Bas de gamme', 3),
('Milieu de gamme', 2),
('Haut de gamme', 1);

-- --------------------------------------------------------

--
-- Structure de la table `produits`
--

DROP TABLE IF EXISTS `produits`;
CREATE TABLE IF NOT EXISTS `produits` (
  `idProduit` int(11) NOT NULL AUTO_INCREMENT,
  `nomProduit` varchar(40) NOT NULL,
  `gamme` int(11) NOT NULL DEFAULT '0',
  `description` varchar(100) DEFAULT NULL,
  `noteProduit` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idProduit`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `produits`
--

INSERT INTO `produits` (`idProduit`, `nomProduit`, `gamme`, `description`, `noteProduit`) VALUES
(1, 'Ordinateur de bureau', 2, 'Ordinateur utilisé sur endroit fixe à cause de ses dimensions, de sa masse et de son alimentation.', 4),
(2, 'Souris sans fil', 2, 'Souris un peu moins performante mais tellement moins encombrante.', 3),
(3, 'Souris filaire', 1, 'Souris plus performante mais aussi plus encombrante.', 4),
(4, 'Iphone 12', 1, 'Téléphone de chez Apple.', 5),
(5, 'Drone', 2, 'Les drones sont des aéronefs sans équipage dont le pilotage est automatique ou télécommandé.', 4),
(31, 'Samsung galaxy S8+', 1, 'Téléphone de chez Samsung.', 5),
(32, 'Enceinte connectée', 3, 'Haut-parleur sans fil permettant d\'écouter dans la musique plus forte qu\'avec son téléphone.', 3),
(33, 'Airpods', 1, 'Ecouteur sans fil de chez Apple, sortie : 2016.', 5),
(34, 'Montre connectée', 2, 'Une montre qui indique le nombre de pas, l\'heure, les appels et les messages reçus.', 4),
(35, 'Ampoule E14 40W', 3, 'Ampoule de rayon 14.', 2),
(36, 'Ampoule E16 40W', 3, 'Ampoule de rayon 16.', 3),
(37, 'Ecran HD 60Hz 19 pouces', 3, 'Ecran de bonne qualité.', 2),
(38, 'Ecran FHD 60Hz 27 pouces', 2, 'Ecran de moyenne qualité.', 3),
(39, 'Ecran FHD 144Hz 27 pouces', 1, 'Ecran de mauvaise qualité.', 4),
(40, 'RAM 8Go', 2, 'Mémoire vive de 8Go.', 1),
(41, 'RAM 16Go', 2, 'Mémoire vive de 16Go.', 2),
(42, 'Processeur intel core i5 9th Gen', 2, 'Processeur 9ème génération de chez Intel.', 4),
(43, 'Disque dur 1To', 2, 'Espace de stockage de 1To.', 5),
(44, 'Processeur intel core i7 9th Gen', 1, 'Processeur 9ème génération de chez Intel.', 4),
(45, 'Pc Portable', 2, 'Ordinateur portable de moyenne qualité.', 3),
(46, 'Pc Portable', 1, 'Ordinateur portable de bonne qualité.', 4),
(47, 'Clef USB 8Go', 3, 'Espace de stockage de 8Go.', 2),
(48, 'Clef USB 32Go', 2, 'Espace de stockage de 32Go.', 3),
(49, 'Clef USB 64Go', 2, 'Espace de stockage de 64Go.', 4),
(50, 'Ventilateur', 1, 'Permet de se rafraîchir en été', 2),
(51, 'Réfrigérateur', 2, 'Permet de stocker des aliments au frais pour les conserver sur une longue durée.', 4),
(52, 'Climatisation', 1, 'Utile pour rafraîchir une pièce.', 3),
(53, 'Machine à laver', 2, 'Permet de laver le linge sale.', 4),
(54, 'Sèche linge', 2, 'Outil électroménager permettant de sécher rapidement le linge.', 3),
(55, 'Micro onde', 2, 'Permet de réchauffer / faire cuire des aliments.', 3);

-- --------------------------------------------------------

--
-- Structure de la table `sites`
--

DROP TABLE IF EXISTS `sites`;
CREATE TABLE IF NOT EXISTS `sites` (
  `idSite` int(11) NOT NULL AUTO_INCREMENT,
  `nomSite` varchar(25) NOT NULL,
  `urlSite` varchar(50) NOT NULL,
  `noteSite` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idSite`)
) ENGINE=MyISAM AUTO_INCREMENT=152 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `sites`
--

INSERT INTO `sites` (`idSite`, `nomSite`, `urlSite`, `noteSite`) VALUES
(1, 'Amazon', 'https://www.amazon.fr/', 12),
(5, 'Fnac', 'https://www.fnac.com/', 14),
(2, 'TopAchat', 'https://www.topachat.com/', 15),
(8, 'Cdiscount', 'https://www.cdiscount.com/', 13),
(3, 'Boulanger', 'https://www.boulanger.com/', 13),
(4, 'Darty', 'https://www.darty.com/', 11),
(10, 'Rue du commerce', 'https://www.rueducommerce.fr/', 15),
(11, 'Samsung', 'https://www.samsung.com/', 18),
(12, 'Apple', 'https://www.apple.com/', 17),
(13, 'OnePlus', 'https://www.oneplus.com/', 16),
(14, 'LDLC', 'https://www.ldlc.com/', 8),
(15, 'materiel.net', 'https://www.materiel.net/', 10),
(16, 'AliExpress', 'https://best.aliexpress.com/', 3),
(17, 'Wish', 'https://www.wish.com/', 1),
(18, 'Electrodepot', 'https://www.electrodepot.fr/', 6);

-- --------------------------------------------------------

--
-- Structure de la table `types`
--

DROP TABLE IF EXISTS `types`;
CREATE TABLE IF NOT EXISTS `types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Types` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `types`
--

INSERT INTO `types` (`id`, `Types`) VALUES
(1, 'Electroménager'),
(2, 'Informatique'),
(3, 'Jeux vidéos'),
(4, 'High-Tech');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(25) NOT NULL,
  `passe` varchar(25) NOT NULL,
  `admin` int(11) NOT NULL,
  `blacklist` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `pseudo`, `passe`, `admin`, `blacklist`) VALUES
(1, 'admin', 'admin', 1, 0),
(2, 'leo', 'mdp', 0, 0),
(3, 'alex', 'mdp', 0, 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
